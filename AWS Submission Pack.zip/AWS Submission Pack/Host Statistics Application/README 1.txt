Note:
1. Ensure the FleetState file is kept at this root folder