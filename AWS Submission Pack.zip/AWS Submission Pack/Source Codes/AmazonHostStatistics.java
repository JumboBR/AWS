/*
This program is intended to load state of fleets from an input file, compute
some summary statistics, and finally writes to an output file
 */

/**
 *
 * @author Jumbo B. Rowland
 */
import HostStatistics.HostStatistics;

public class AmazonHostStatistics {

    public static void main(String[] args) {
        //get host statistics object
        HostStatistics statisticsObj = new HostStatistics();
        
        System.out.println("Host summary statistics computation has started ...");
        
        //get host statistics
        statisticsObj.getHostStatistics();
        
    }//end of main
    
}//end of class
