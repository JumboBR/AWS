/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

/**
 *
 * @author NyingiJ
 */
public class AmazonHostStatisticsTest {
    
    public AmazonHostStatisticsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {

    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of main method, of class AmazonHostStatistics.
     */
    @Test
    public void testMain() {
        System.out.println("AmazonHostStatisticsTest main:\n"
                + "Testing generated summary statistics and expected format");
        String expectedString = "";//initialize with an empty string
        
        String actualString = "";//initialize with an empty string


        //check if the ideal content is the same in the output file
            //get the content from the outputed file
        try {
                File ideal_File = new File ("ideal_statistics.txt");
                File actual_File = new File("statistics.txt");

                //check if file exists
                try{
                    if(actual_File.exists()){
                        System.out.println("File Aready Exists! Deleting current output \"statistics.txt\" file");
                        actual_File.delete();
                        
                        //check if file was successfully deleted
                        if(actual_File.exists()== false){
                            System.out.println("File Deleted!");
                            }
                        else{
                            System.out.println("Please manually delete \"statistics.txt\" file");
                        }
                        //rerun the program to create a new file
                        System.out.println("\nRerunning the program for a newer output file");
                        AmazonHostStatistics.main(null);
                        System.out.println("\nProgram ran successfully! New File Created!\nCommencing Test");
                    }//end of if
                }catch(Exception e){
                    System.out.println("Error accessing statistics.txt file");
                }
                
                Scanner actualFileScanner = new Scanner(actual_File);
                Scanner idealFileScanner = new Scanner(ideal_File);
                
                boolean check = actual_File.exists();
                boolean check2 = ideal_File.exists();
                
                if (check == true && check2 == true){
                    //check the contents of the file with the expected string
                    //loop and read file
                    while (actualFileScanner.hasNextLine()){
                        actualString =  actualFileScanner.nextLine();
                        expectedString = idealFileScanner.nextLine();
                    }//end of while
                }//end of if
                else{
                    System.out.println("File not found");
                }
            }//end of try
            catch(Exception e){
                System.out.println("Error accessing file!");
            }//end of catch
        

        //use the assertSame statement and check same content
        assertEquals(expectedString,actualString);
        
        System.out.println("Successfully Completed Test!");
        
        }
            
    }
    

