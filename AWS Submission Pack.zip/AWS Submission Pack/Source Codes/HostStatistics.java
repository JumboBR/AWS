/*
 * This class computes summary statistics for host - instances from received data file
 * ArrayLists are used 
 * 
 */
package HostStatistics;

import HostStatistics.utility.ReadTextUtil;
import HostStatistics.utility.WriteHostStatToFileUtil;
import java.util.ArrayList;

/**
 * @author Jumbo Rowland
 */

public class HostStatistics {
    //local variables
        //these variables hold info from each record read from the file

    final int FIXEDSLOTS = 14;
    final int RECORDHEADERCOUNT = 3;
        /*it is 3 because in each record from the FleetState.txt file each row had HostID, Instance type, no. of states first before the states; thus 3 in number*/
    final int FIXEDRECORDLENGTH = FIXEDSLOTS + RECORDHEADERCOUNT;//Remember to subtract 1 if you are looping from 0
    
     
    public void getHostStatistics(){

        //get data from file
        ArrayList<String> hostDetailRecord = getDataFromFile();
        
        //process received data from file
            //create a multidiemsional array that can hold all the records from the read file
                    //note, records are every horizontal line in the text file and fields are columns
                        //multidimensional arrays are in [rows][cols]
        String[][] recordAndField = new String[hostDetailRecord.size()][FIXEDRECORDLENGTH];//This creates the multi-array  to exact size

        //create a one dimensional array to use for splitting records to fields using "," delimeter
        String[] records = new String[hostDetailRecord.size()];//set the size to the amount of records recieved
        //convert the arraylist to string array for easier manipulation
        for(int i=0; i<hostDetailRecord.size(); i++){
           records[i]= hostDetailRecord.get(i); 
        }

        //identify fields from the records
            //loop the individual rows and split them by "," delimeters
        for(int i =0; i<records.length;i++){//because int i = 0, I also used < for the loop instead of <= if int i was 1
            //loop and split for columns
            //split the record into another array
                String[] columnArray = records[i].split(",");
                //second loop
                for (int j = 0; j<columnArray.length; j++){//remember to change 13 to a variable
                    //now use j to loop the splitted array and extract its contents
                    recordAndField[i][j] = columnArray[j];
                }//end of inner for 1 of 2
        }//end of for 2 or 2
        
        //now start counting
        countAndDisplayData(records, recordAndField);
        
    }//end of method getHostStatistics
    
    //method for getting data from stored file
    private ArrayList<String> getDataFromFile(){
        //create data retrieval objects
        ReadTextUtil readTextUtil = new ReadTextUtil ();

        //identify records from the array
        ArrayList<String> hostDetailRecord = readTextUtil.readRecords();

        return hostDetailRecord;
    }//end of method getDataFromFile
    
    //method for summary statistics and results display
    private void countAndDisplayData(String[] records, String[][] recordAndField){
        //initialize counting variables to 0. This is faster than m1_Count = m2_Count = 0;
        int m1_Count = 0;
        int m2_Count = 0;
        int m3_Count = 0;
        int m1_FilledStateCount = 0;
        int m2_FilledStateCount = 0;
        int m3_FilledStateCount = 0;
        int m1_EmptyStateCount = 0;
        int m2_EmptyStateCount = 0;
        int m3_EmptyStateCount = 0;
        
        //loop and count
        for (int row = 0; row<records.length; row++){
            for (int col = 0; col<records[row].split(",").length; col++){//The records was split again here to avoid the errors in targeting a multidimensional arrays's col. The cols are dynamic
                //use if statements to count
                if(recordAndField[row][col].equalsIgnoreCase("M1")){
                    m1_Count ++;
                }//end of m1 if
                else if (recordAndField[row][col].equalsIgnoreCase("M2")){
                    m2_Count ++;
                }//end of m2 if
                else if (recordAndField[row][col].equalsIgnoreCase("M3")){
                    m3_Count ++;
                }//end of m3 if
                else if (recordAndField[row][col].equalsIgnoreCase("1")){
                    //populate the originating instance
                    switch (recordAndField[row][(col-col)+1]){
                        case "M1":
                            m1_FilledStateCount ++;
                            break;
                        case "M2":
                            m2_FilledStateCount ++;
                            break;
                        case "M3":
                            m3_FilledStateCount ++;
                            break;
                        default:
                            //test
                            System.out.println("No instances found");
                            System.out.println("invalid record");
                            break;
                    }//end of m1 switch
                }//end of 1 if
                else if (recordAndField[row][col].equalsIgnoreCase("0")){
                    //populate the originating instance
                    switch (recordAndField[row][(col-col)+1]){
                        case "M1":
                            m1_EmptyStateCount ++;
                            break;
                        case "M2":
                            m2_EmptyStateCount ++;
                            break;
                        case "M3":
                            m3_EmptyStateCount ++;
                            break;
                        default:
                            //test
                            System.out.println("No instances found");
                            System.out.println("invalid record");
                            break;
                    }//end of m1 switch
                }//end of 0 if
            }//end of inner for 1 of 2
        }//end of outer for 2 of 2
            

        //Summary Statistics Hints
        System.out.println("Summary Statistics Hint:\n........................");
            System.out.println("M1 total: "+m1_Count);
            System.out.println("M2 total: "+m2_Count);
            System.out.println("M3 total: "+m3_Count);
            System.out.println("M1 filled state total: "+m1_FilledStateCount);
            System.out.println("M2 filled state total: "+m2_FilledStateCount);
            System.out.println("M3 filled state total: "+m3_FilledStateCount);
            System.out.println("M1 empty state total: "+m1_EmptyStateCount);
            System.out.println("M2 empty state total: "+m2_EmptyStateCount);
            System.out.println("M3 empty state total: "+m3_EmptyStateCount);
            
        //now write results to file
        WriteHostStatToFileUtil fw = new WriteHostStatToFileUtil();
        fw.writeHostStatToFileUtil(m1_Count, m2_Count, m3_Count, m1_FilledStateCount, m2_FilledStateCount, m3_FilledStateCount, m1_EmptyStateCount, m2_EmptyStateCount, m3_EmptyStateCount);

    }

    

}//end of class