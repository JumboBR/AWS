/*
 * This class receives specifically hosts data and writes to a file named:
 *  Statistics.txt
 * 
 * 
 */
package HostStatistics.utility;

import java.io.File;


/**
 *
 * @author Jumbo Rowland
 */
public class WriteHostStatToFileUtil {
    String OUTPUTFILENAME = "statistics.txt";
    
    public void writeHostStatToFileUtil(int m1_Count, int m2_Count, int m3_Count,
            int m1_FilledStateCount, int m2_FilledStateCount, int m3_FilledStateCount,
                int m1_EmptyStateCount, int m2_EmptyStateCount, int m3_EmptyStateCount){
        //get contents to write to file
        
        
        //open or create a file to write to
            //ensure it handles already existing file
        String statReport = getStatReportFrameWork(m1_Count, m2_Count, m3_Count,
            m1_FilledStateCount, m2_FilledStateCount, m3_FilledStateCount,
                m1_EmptyStateCount, m2_EmptyStateCount, m3_EmptyStateCount);
        
    
        //write to the file
        openFileAndWrite(OUTPUTFILENAME, statReport);//method also closes file
    
        //notify user using JOptionPane show method
        notifyUser(OUTPUTFILENAME);
        
        System.out.println("Output file: "+OUTPUTFILENAME+" created!");
    
    }//end of method writeHostStatToFileUtil
    
    private String getStatReportFrameWork(int m1_Count, int m2_Count, int m3_Count,
            int m1_FilledStateCount, int m2_FilledStateCount, int m3_FilledStateCount,
                int m1_EmptyStateCount, int m2_EmptyStateCount, int m3_EmptyStateCount){
        
        String reportFrameWork = "EMPTY:M1="+m1_EmptyStateCount+";M2="+m2_EmptyStateCount+
                ";M3="+m3_EmptyStateCount+";\r\n"+
                "FULL:M1="+m1_FilledStateCount+";M2="+m2_FilledStateCount+";M3="+
                m3_FilledStateCount+";\r\n"+
                "MOST FILLED:M1="+m1_Count+","+m1_EmptyStateCount+";M2="+m2_Count+
                ","+m2_EmptyStateCount+";M3="+m3_Count+","+m3_EmptyStateCount+";";
        
        return reportFrameWork;
    }
    
    private void openFileAndWrite(String fileName, String reportContext){
        
        try{
                //this will always overwrite the file.
                    //would have included date and time stamp on the stats report
                        //but it appears the output file has a strict appearance
                java.io.FileWriter fileToWriteTo = new java.io.FileWriter(new File(".\\"+OUTPUTFILENAME));
                //create writer
                java.io.BufferedWriter fw = new java.io.BufferedWriter(fileToWriteTo);
                

                //write
                fw.write(reportContext);

                //close file
                fw.close();

            


        }//end of try
        catch (Exception e){
            javax.swing.JOptionPane.showMessageDialog(null, "Statistics report was not "
                    + "generated successfully.\nContact the system administrator");
        }//end of catch
    }//end of openFileAndWrite

    
    private void notifyUser(String fileName){
        javax.swing.JOptionPane.showMessageDialog(null, fileName+" file report was "
                + "created successfully");
    
    }
    

}//end of class
