/*
 * This class reads text from a file and returns and array list
 * 
 * 
 */
package HostStatistics.utility;
/**
 *
 * @author Jumbo Rowland
 */

import java.io.FileNotFoundException;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class ReadTextUtil {
    //local variables

    
    //Open File to read
    private Scanner openFile(String fileToOpen) {
       Scanner input = null;//initialize with null
        
        try{
           //Note: any file to be read should be in the Project root folder
           File file = new File (fileToOpen);
           
           input = new Scanner (file);
            //for test - it worked
            System.out.println ("Host data file opened successfully");
        }//end of try
        catch(FileNotFoundException fileNotFoundException){
            System.err.println ("Error opening File");//Avoid showing the exception to the user
            //you can log fileNotFoundException
            System.exit(1);
        }//end of catch
        return input;
    }//end of openFile
    
    private void closeFile(Scanner fileToClose){
        //close file
        try{
            fileToClose.close();
            System.out.println("Host data file closed successfully");
        }
        catch(Exception e){
            System.out.println("Unable to close file");//Avoid showing exceptions to the user
            //you can log e
        }
    }//end of close file
    
    //read text and tokenize
    public ArrayList readRecords(){
        //open file to read
        Scanner textFileScanner = openFile("FleetState.txt");
        
        //initialize it with null
        ArrayList <String> hostDetails = new ArrayList<>();//I used diamond operator here i.e. new ArrayList<>();
        
        try{
            //use an array to hold read data, line by line
                //count the entire lines in the file
            int i = 0;//this is used in the while loop below
            while (textFileScanner.hasNextLine()){
                //test - it worked in printing the whole text
                hostDetails.add(textFileScanner.nextLine());
                i++;
            }//end of while

            //close the open file
            closeFile(textFileScanner);
        }//end of try
        catch(Exception e){
            System.err.println("Error reading data");
        }//end of catch

        return hostDetails;
    }//end of readRecords method
    
}//end of class
